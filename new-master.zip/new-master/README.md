﻿# ADM-ULTIMATE-NEW-FREE

Manager Script

 • RECOMENDADO UBUNTU 14.04

apt-get update -y; apt-get upgrade -y; wget https://raw.githubusercontent.com/diesel09/new/master/instalar.sh; chmod 777 instalar.sh* && ./instalar.sh*



